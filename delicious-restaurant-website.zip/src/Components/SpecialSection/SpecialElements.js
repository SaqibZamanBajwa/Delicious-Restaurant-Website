// import styled from 'styled-components';


// export const Hello = styled.div`
// border: 1px solid blue;
// padding: 20px;
// `

// export const Menubar = styled.div`
// display: flex;
// flex-direction: row;
// max-width: 100%;
// justify-content: center;
// margin: 35px 0;
// `

// export const ActiveMenu = styled.div`
// padding: 8px 16px 10px 16px;
// font-size: 14px;
// line-height: 1;
// color: #444444;
// cursor: pointer;
// margin: 0 5px 10px 5px;
// border-radius: 50px;
// border: 2px solid #FFB03B;
// color: #fff;
// background: #ffb03b;

// `


// export const Menu = styled.div`
// padding: 8px 16px 10px 16px;
// font-size: 14px;
// line-height: 1;
// color: #444444;
// cursor: pointer;
// margin: 0 5px 10px 5px;
// border-radius: 50px;
// border: 2px solid #FFB03B;

// &:hover{
//     color: #fff;
//     background: #ffb03b;
//     transition: all ease-in-out 0.3s;
// }
// `


