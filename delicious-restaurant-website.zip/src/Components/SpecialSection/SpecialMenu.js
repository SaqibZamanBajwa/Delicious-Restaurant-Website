// import React from 'react'
// import { Hello } from './SpecialElements'

// const SpecialMenu = ({ data, cardIndex }) => {
//     return (
//         <>
//             {data[cardIndex].map(item => (
//                 <div>
//                     <Hello>
//                         <p>{item.title}</p>
//                         <p>{item.price}</p>
//                         <p>{item.description}</p>
//                     </Hello>
//                 </div>
//             ))}

//         </>
//     )
// }

// export default SpecialMenu;
