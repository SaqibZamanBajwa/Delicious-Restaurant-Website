// import React from 'react'
// import {Button} from '../ButtonElement'
// // import SaqibZaman from '../../IMGS/SaqibZaman.jpg'
// import Promo from '../../Videos/Promo.mp4';
// import {
//     FirstContainer,
//     FirstWrapper,
//     FirstRow,
//     Column1,
//     Column2,
//     TextWrapper,
//     TopLine,
//     Heading,
//     Subtitle,
//     BtnWrap,
//     // ImgWrap,
//     // Img,
//     VideoWrap,
//     Video
// } from './FirstElements';


// const FirstSection = ({ 
//     lightBg,
//      id,
//     //  imgStart,
//      videoStart,
//      topLine,
//      lightText,
//      headline,
//      darkText,
//      description,
//      buttonLabel,
//     //  img,
    
//      alt,
//      primary,
//      dark,
//      dark2
//     }) => {
//     return (
//         <>
//             <FirstContainer lightBg={lightBg} id={id}>
//                 <FirstWrapper>
//                     {/* <FirstRow imgStart={imgStart}> */}
//                     <FirstRow videoStart={videoStart}>
//                         <Column1>
//                             <TextWrapper>
//                                 <TopLine>{topLine}</TopLine>
//                                 <Heading lightText={lightText}>{headline}</Heading>
//                                 <Subtitle darkText={darkText}>{description}</Subtitle>
//                                 <BtnWrap>
//                                     <Button
//                                      to='home'
//                                      smooth={true}
//                                      duration={500}
//                                      spy={true}
//                                      exact='true'
//                                      offset={-80}
//                                      primary={primary ? 1 : 0}
//                                      dark={dark ? 1 : 0}
//                                      dark2={dark2 ? 1 : 0}
//                                      >
//                                      {buttonLabel}
//                                      </Button>
//                                 </BtnWrap>
//                             </TextWrapper>
//                         </Column1>
//                         <Column2>
//                             {/* <ImgWrap>
//                                 <Img src={SaqibZaman} alt={alt} />
//                             </ImgWrap> */}
//                             <VideoWrap autoPlay loop muted>
//                                 <video src={Promo} type="video/mp4" />
//                                 {/* <iframe width="853" height="480" src="https://www.youtube.com/embed/Gf4JBUiVXYQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>  */}
//                             </VideoWrap>
//                         </Column2>
//                     </FirstRow>
//                 </FirstWrapper>
//             </FirstContainer>
//         </>
//     )
// }

// export default FirstSection;
