// // export const HomeObjOne = {
// //     id: 'about',
// //     lightBg: false,
// //     lightText: true,
// //     lightTextDesc: true,
// //     topLine: 'Eum ipsum deleniti velit pariatur architecto aut nihil',
// //     headline: 'Unlimited Transactions with zero fees',
// //     description: 'Get access to our exclusive app that allowws you to send unlimited transactions without getting charged any fees.',
// //     buttonLabel: 'Get Started',
// //     imgStart: true,
// //     img: require('../../IMGS/SaqibZaman.jpg'),
// //     alt: 'Car',
// //     dark: true,
// //     primary: true,
// //     darkText: false
// // }
// export const HomeObjOne = {
//     id: 'about',
//     lightBg: false,
//     lightText: true,
//     lightTextDesc: true,
//     topLine: 'Eum ipsum deleniti velit pariatur architecto aut nihil',
//     headline: 'Unlimited Transactions with zero fees',
//     description: 'Get access to our exclusive app that allowws you to send unlimited transactions without getting charged any fees.',
//     buttonLabel: 'Get Started',
//     // imgStart: true,
//     videoStart: true,
//     video: require('../../Videos/Promo.mp4'),
//     dark: true,
//     primary: true,
//     darkText: false
// }