import React from 'react'
import All from './Menu'


const MenuBarSection = () => {
    return (
        <div>
            <All/>
        </div>
    )
}

export default MenuBarSection;
